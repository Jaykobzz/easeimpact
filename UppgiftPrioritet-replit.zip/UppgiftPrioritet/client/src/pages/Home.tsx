import TaskPriorityApp from "@/components/TaskPriorityApp";

export default function Home() {
  return <TaskPriorityApp />;
}