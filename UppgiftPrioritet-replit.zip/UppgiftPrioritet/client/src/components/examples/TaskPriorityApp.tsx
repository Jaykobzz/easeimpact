import TaskPriorityApp from '../TaskPriorityApp';

export default function TaskPriorityAppExample() {
  return <TaskPriorityApp />;
}